<?php
header("Location: http://www.mricon.com/");
?>
