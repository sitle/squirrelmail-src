<?php
        $force = 1;
	$retrieve_on_every_login = 0;
	$retrieve_data_from = "ldap.php";

	$ldap_server = "ldap.wiwi.uni-rostock.de";
	$ldap_username = "cn";
	$ldap_mail = "mail";
	$ldap_base_dn = "ou=people,dc=wiwi,dc=uni-rostock,dc=de";
?>
