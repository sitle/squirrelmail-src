<?php
  function squirrelmail_plugin_init_vchpass(){
  	global $squirrelmail_plugin_hooks;
	$squirrelmail_plugin_hooks["options_link_and_description"]["vchpass"] = "vchpass_setup";

  }

  function vchpass_setup(){
   global $color
   ?>
   <table width=50% cellpadding=3 cellspacing=0 border=0 align=center>
     <tr>
      <td bgcolor="<?php echo $color[9] ?>">
       <a href="../plugins/vchpass/vchpass.php">Change Password</a>
      </td>
     </tr>
     <tr>
      <td bgcolor="<?php echo $color[0] ?>">
       You may change the password that you use to log in and
       check your e-mail.
      </td>
     </tr>
    </table>
    <?php
   }
?>
